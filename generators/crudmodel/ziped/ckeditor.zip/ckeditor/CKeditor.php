<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @return CWebApplication
 */

/**
 * Description of CKeditors
 *
 * @author Kalman
 */
class CKeditor extends CInputWidget
{
    public function init()
    {
        $assets = Yii::app()->assetManager->publish(__DIR__);
        $cs = Yii::app()->clientScript;
        $cs->registerScriptFile($assets . '/ckeditor.js');
    }

    public function run()
    {
        echo CHtml::activeTextArea($this->model, $this->attribute, array('class'=>'ckeditor'));
    }
}

?>
