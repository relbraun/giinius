<?php

class Dropzone extends CInputWidget
{
    public function init()
    {
        $assets = Yii::app()->assetsManager->publish(__DIR__);
        /** @var CClientScript $cs */
        $cs = Yii::app()->clientScript;
        $cs->registerCoreScript('jquery');
        $cs->registerScriptFile($assets . '/dropzone.js');
    }

    public function run()
    {
        CHtml::resolveNameID($this->model, $this->attribute, $this->htmlOptions);
        $id=$this->htmlOptions['id'];
        $script = '$(\'#'.$id.'\').dropzone({ url: "/file/post" });';
        Yii::app()->clientScript->registerScript(__FILE__, $script);
        echo CHtml::activeFileField($this->model, $this->attribute, $this->htmlOptions);
    }
}