<?php

return array(
   'Upload Files' => 'העלה קבצים לכאן',
    'Drop Files Here.' => 'גרור קבצים לכאן',
    'Close' => 'סגור'
);
