<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
Yii::import('zii.widgets.grid.CButtonColumn');
/**
 * Description of BootstrapButtonColumn
 *
 * @author Kalman
 */
class BootstrapButtonColumn extends CButtonColumn
{

    public $viewButtonImageUrl=false;

    public $updateButtonImageUrl=false;


    public $deleteButtonImageUrl=false;


    public $buttons=array(
        'view'=>array(
            'content'=>'<span class="glyphicon glyphicon-search"></span>',
        ),
        'update'=>array(
            'content'=>'<span class="glyphicon glyphicon-pencil"></span>',
        ),
        'delete'=>array(
            'content'=>'<span class="glyphicon glyphicon-remove-sign"></span>',
        ),
    );

    protected function renderButton($id,$button,$row,$data)
	{
		if (isset($button['visible']) && !$this->evaluateExpression($button['visible'],array('row'=>$row,'data'=>$data)))
  			return;
		$label=isset($button['label']) ? $button['label'] : $id;
		$url=isset($button['url']) ? $this->evaluateExpression($button['url'],array('data'=>$data,'row'=>$row)) : '#';
		$options=isset($button['options']) ? $button['options'] : array();
                $content=isset($button['content']) ? $button['content'] : $label;
		if(!isset($options['title']))
			$options['title']=$label;
		if(isset($button['imageUrl']) && is_string($button['imageUrl']))
			echo CHtml::link(CHtml::image($button['imageUrl'],$label),$url,$options);
		else
			echo CHtml::link($content,$url,$options);
	}
}

?>
